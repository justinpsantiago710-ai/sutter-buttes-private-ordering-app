const merchants = [
  {
    name: "Tractor Gas",
    type: "flower",
    detail: "Gelato 41 x Lemon Fuel - flower drop",
    image: "assets/IMG_6477.png"
  },
  {
    name: "Zodashi",
    type: "flower",
    detail: "Zoda x Zonuts - curated drop",
    image: "assets/IMG_6478.png"
  },
  {
    name: "Dog Food",
    type: "flower",
    detail: "Lemon Cherry Gelato x London Poundcake x Jealousy",
    image: "assets/IMG_6479.png"
  },
  {
    name: "Rosin Syrups",
    type: "syrup",
    detail: "Cucumber, pineapple, watermelon, chile mango",
    image: "assets/IMG_6480.png"
  },
  {
    name: "Permanent Marker Rosin",
    type: "concentrate",
    detail: "Solventless concentrate - small batch",
    image: "assets/IMG_6475.png"
  },
  {
    name: "Sutter Buttes Hat",
    type: "apparel",
    detail: "Logo apparel - limited colorway",
    image: "assets/IMG_6475.png"
  }
];

const merchantOrders = [
  ["#4191", "2 products - ID check required at delivery", "Verify"],
  ["#4197", "1 syrup, 1 flower jar - driver assigned", "Pack"],
  ["#4200", "Logo hat - pickup with verified order", "Queued"]
];

const defaultCatalog = [
  { id: "item-1", name: "Tractor Gas Flower", price: 42, category: "Flower", description: "Gelato 41 x Lemon Fuel strain art drop.", image: "assets/IMG_6477.png", active: true },
  { id: "item-2", name: "Zodashi Flower", price: 42, category: "Flower", description: "Zoda x Zonuts with bold samurai artwork.", image: "assets/IMG_6478.png", active: true },
  { id: "item-3", name: "Dog Food Flower", price: 42, category: "Flower", description: "Lemon Cherry Gelato x London Poundcake x Jealousy.", image: "assets/IMG_6479.png", active: true },
  { id: "item-4", name: "Cucumber Peppino Syrup", price: 28, category: "Syrup", description: "THC tincture syrup, cucumber lime profile.", image: "assets/IMG_6480.png", active: true },
  { id: "item-5", name: "Pineapple Pina Syrup", price: 28, category: "Syrup", description: "THC tincture syrup with pineapple flavor.", image: "assets/IMG_6480.png", active: true },
  { id: "item-6", name: "Watermelon Tamarindo Syrup", price: 28, category: "Syrup", description: "THC tincture syrup with watermelon tamarindo flavor.", image: "assets/IMG_6480.png", active: true },
  { id: "item-7", name: "Chile Mango Syrup", price: 28, category: "Syrup", description: "THC tincture syrup with chile mango flavor.", image: "assets/IMG_6480.png", active: true },
  { id: "item-8", name: "Permanent Marker Rosin", price: 50, category: "Concentrate", description: "Small-batch concentrate placeholder.", image: "assets/IMG_6475.png", active: false },
  { id: "item-9", name: "Sutter Buttes Hat", price: 30, category: "Apparel", description: "Black and white trucker hat with mountain logo.", image: "assets/IMG_6475.png", active: true }
];
const catalogVersion = "sutter-products-v4";

const defaultDesign = {
  name: "Sutter Buttes",
  color: "#193429",
  preset: "fresh"
};
const defaultFrontPage = {
  heroEyebrow: "Licensed dispensary",
  heroTitle: "Sutter Buttes",
  heroDescription: "Legal cannabis delivery from Yuba City with ID verification at drop-off.",
  brandEyebrow: "Est. 2026",
  brandHeadline: "Sutter Buttes Cannabis Co.",
  brandDescription: "Mountain-grown energy, curated drops, local delivery.",
  featuredDrop: "11PM",
  featuredDescription: "Curated by Sutter Buttes Cannabis Co.",
  flowerNote: "Tractor Gas, Zodashi, Dog Food, 11PM.",
  syrupNote: "Mango, pineapple, cucumber, watermelon, chile.",
  apparelNote: "Trucker hats, tees, limited collab pieces."
};
const defaultPromo = {
  visible: true,
  eyebrow: "Private drop",
  headline: "Weekend menu update",
  description: "Fresh flower, syrup flavors, and merch drops are live.",
  button: "Shop now",
  logoImage: "",
  heroImage: ""
};
const accessCode = "BUTTES2026";

let basketCount = 0;
let activeFilter = "all";
let catalog = loadCatalog();
let design = loadDesign();
let frontPage = loadFrontPage();
let promo = loadPromo();
let editingItemId = null;
let pendingImageData = "";
let pendingLogoData = "";
let pendingHeroData = "";

const modeButtons = document.querySelectorAll(".mode");
const views = {
  customer: document.getElementById("customerView"),
  merchant: document.getElementById("merchantView"),
  catalog: document.getElementById("catalogView"),
  design: document.getElementById("designView"),
  frontpage: document.getElementById("frontpageView"),
  promo: document.getElementById("promoView")
};
const merchantList = document.getElementById("merchantList");
const basketSummary = document.getElementById("basketSummary");
const searchInput = document.getElementById("searchInput");
const searchRow = document.querySelector(".search-row");
const basketBar = document.querySelector(".basket-bar");
const catalogList = document.getElementById("catalogList");
const catalogForm = document.getElementById("catalogForm");
const itemNameInput = document.getElementById("itemName");
const itemPriceInput = document.getElementById("itemPrice");
const itemDescriptionInput = document.getElementById("itemDescription");
const itemCategoryInput = document.getElementById("itemCategory");
const itemImageUrlInput = document.getElementById("itemImageUrl");
const itemImageFileInput = document.getElementById("itemImageFile");
const catalogSubmitButton = document.getElementById("catalogSubmitButton");
const cancelEditButton = document.getElementById("cancelEditButton");
const designForm = document.getElementById("designForm");
const brandNameInput = document.getElementById("brandNameInput");
const brandColorInput = document.getElementById("brandColorInput");
const stylePresetInput = document.getElementById("stylePresetInput");
const frontPageForm = document.getElementById("frontPageForm");
const frontPageInputs = {
  heroEyebrow: document.getElementById("heroEyebrowInput"),
  heroTitle: document.getElementById("heroTitleInput"),
  heroDescription: document.getElementById("heroDescriptionInput"),
  brandEyebrow: document.getElementById("brandEyebrowInput"),
  brandHeadline: document.getElementById("brandHeadlineInput"),
  brandDescription: document.getElementById("brandDescriptionInput"),
  featuredDrop: document.getElementById("featuredDropInput"),
  featuredDescription: document.getElementById("featuredDescriptionInput"),
  flowerNote: document.getElementById("flowerNoteInput"),
  syrupNote: document.getElementById("syrupNoteInput"),
  apparelNote: document.getElementById("apparelNoteInput")
};
const accessForm = document.getElementById("accessForm");
const accessCodeInput = document.getElementById("accessCodeInput");
const accessError = document.getElementById("accessError");
const promoForm = document.getElementById("promoForm");
const promoInputs = {
  visible: document.getElementById("promoVisibleInput"),
  eyebrow: document.getElementById("promoEyebrowInput"),
  headline: document.getElementById("promoHeadlineInput"),
  description: document.getElementById("promoDescriptionInput"),
  button: document.getElementById("promoButtonInput"),
  logoImage: document.getElementById("logoImageUrlInput"),
  logoFile: document.getElementById("logoImageFileInput"),
  heroImage: document.getElementById("heroImageUrlInput"),
  heroFile: document.getElementById("heroImageFileInput")
};

function setMode(mode) {
  modeButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.mode === mode);
  });

  Object.entries(views).forEach(([key, view]) => {
    view.classList.toggle("active", key === mode);
  });

  const isCustomer = mode === "customer";
  searchRow.style.display = isCustomer ? "block" : "none";
  basketBar.style.display = isCustomer ? "flex" : "none";
}

function loadCatalog() {
  const savedVersion = localStorage.getItem("sutterButtesCatalogVersion");
  const saved = localStorage.getItem("sutterButtesCatalog");
  return saved && savedVersion === catalogVersion ? JSON.parse(saved) : [...defaultCatalog];
}

function saveCatalog() {
  localStorage.setItem("sutterButtesCatalogVersion", catalogVersion);
  localStorage.setItem("sutterButtesCatalog", JSON.stringify(catalog));
}

function loadDesign() {
  const saved = localStorage.getItem("sutterButtesDesign");
  return saved ? JSON.parse(saved) : { ...defaultDesign };
}

function saveDesign() {
  localStorage.setItem("sutterButtesDesign", JSON.stringify(design));
}

function loadFrontPage() {
  const saved = localStorage.getItem("sutterButtesFrontPage");
  return saved ? { ...defaultFrontPage, ...JSON.parse(saved) } : { ...defaultFrontPage };
}

function saveFrontPage() {
  localStorage.setItem("sutterButtesFrontPage", JSON.stringify(frontPage));
}

function loadPromo() {
  const saved = localStorage.getItem("sutterButtesPromo");
  return saved ? { ...defaultPromo, ...JSON.parse(saved) } : { ...defaultPromo };
}

function savePromo() {
  localStorage.setItem("sutterButtesPromo", JSON.stringify(promo));
}

function lockApp() {
  localStorage.removeItem("sutterButtesAccess");
  document.body.classList.add("locked");
  accessCodeInput.value = "";
  accessError.textContent = "";
  setTimeout(() => accessCodeInput.focus(), 50);
}

function unlockApp() {
  localStorage.setItem("sutterButtesAccess", "granted");
  document.body.classList.remove("locked");
}

function initializeAccessGate() {
  const hasAccess = localStorage.getItem("sutterButtesAccess") === "granted";
  document.body.classList.toggle("locked", !hasAccess);
}

function applyDesign() {
  document.documentElement.style.setProperty("--mint", design.color);
  document.documentElement.style.setProperty("--mint-dark", design.color);
  document.body.classList.toggle("theme-premium", design.preset === "premium");
  document.body.classList.toggle("theme-bright", design.preset === "bright");
  document.getElementById("brandPreviewName").textContent = design.name;
  document.getElementById("notesTitle").textContent = `${design.name} Platform`;
  document.title = `${design.name} Delivery`;
  brandNameInput.value = design.name;
  brandColorInput.value = design.color;
  stylePresetInput.value = design.preset;
}

function applyFrontPage() {
  document.getElementById("heroEyebrow").textContent = frontPage.heroEyebrow;
  document.getElementById("heroMerchantName").textContent = frontPage.heroTitle;
  document.getElementById("heroDescription").textContent = frontPage.heroDescription;
  document.getElementById("brandEyebrow").textContent = frontPage.brandEyebrow;
  document.getElementById("brandHeadline").textContent = frontPage.brandHeadline;
  document.getElementById("brandDescription").textContent = frontPage.brandDescription;
  document.getElementById("featuredDropName").textContent = frontPage.featuredDrop;
  document.getElementById("featuredDropDescription").textContent = frontPage.featuredDescription;
  document.querySelector(".digital-badge").textContent = frontPage.featuredDrop;
  document.getElementById("flowerNote").textContent = frontPage.flowerNote;
  document.getElementById("syrupNote").textContent = frontPage.syrupNote;
  document.getElementById("apparelNote").textContent = frontPage.apparelNote;

  Object.entries(frontPageInputs).forEach(([key, input]) => {
    input.value = frontPage[key] || "";
  });
}

function applyPromo() {
  const promoBanner = document.getElementById("promoBanner");
  const brandLogoImage = document.getElementById("brandLogoImage");
  const mountainMark = document.getElementById("mountainMark");

  promoBanner.hidden = !promo.visible;
  document.getElementById("promoEyebrow").textContent = promo.eyebrow;
  document.getElementById("promoHeadline").textContent = promo.headline;
  document.getElementById("promoDescription").textContent = promo.description;
  document.getElementById("promoButton").textContent = promo.button;

  if (promo.logoImage) {
    brandLogoImage.src = promo.logoImage;
    brandLogoImage.hidden = false;
    mountainMark.hidden = true;
  } else {
    brandLogoImage.hidden = true;
    mountainMark.hidden = false;
  }

  if (promo.heroImage) {
    document.documentElement.style.setProperty("--hero-image", `url("${promo.heroImage}")`);
  } else {
    document.documentElement.style.setProperty("--hero-image", "url(\"https://images.unsplash.com/photo-1603909223429-69bb7101f420?auto=format&fit=crop&w=900&q=80\")");
  }

  promoInputs.visible.checked = promo.visible;
  promoInputs.eyebrow.value = promo.eyebrow;
  promoInputs.headline.value = promo.headline;
  promoInputs.description.value = promo.description;
  promoInputs.button.value = promo.button;
  promoInputs.logoImage.value = promo.logoImage.startsWith("data:") ? "" : promo.logoImage;
  promoInputs.heroImage.value = promo.heroImage.startsWith("data:") ? "" : promo.heroImage;
}

function addToBasket(amount = 1) {
  basketCount += amount;
  basketSummary.textContent = `${basketCount} ${basketCount === 1 ? "item" : "items"}`;
}

function readUploadedImage(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener("load", () => resolve(reader.result));
    reader.addEventListener("error", reject);
    reader.readAsDataURL(file);
  });
}

function resetCatalogForm() {
  editingItemId = null;
  pendingImageData = "";
  catalogForm.reset();
  catalogSubmitButton.textContent = "Add item";
  cancelEditButton.hidden = true;
}

function renderMerchants() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = merchants.filter((merchant) => {
    const matchesFilter = activeFilter === "all" || merchant.type === activeFilter;
    const matchesSearch = !query || `${merchant.name} ${merchant.type}`.toLowerCase().includes(query);
    return matchesFilter && matchesSearch;
  });

  merchantList.innerHTML = filtered.map((merchant) => `
    <article class="store-card">
      <img class="store-image" src="${merchant.image}" alt="${merchant.name}">
      <div>
        <h3>${merchant.name}</h3>
        <p>${merchant.detail}</p>
      </div>
      <button class="mini-button" type="button" aria-label="Add from ${merchant.name}" data-add>+</button>
    </article>
  `).join("");

  merchantList.querySelectorAll("[data-add]").forEach((button) => {
    button.addEventListener("click", () => addToBasket());
  });
}

function renderCards(targetId, items, className) {
  const target = document.getElementById(targetId);
  target.innerHTML = items.map(([title, detail, tag]) => `
    <article class="${className}">
      <div>
        <h3>${title}</h3>
        <p>${detail}</p>
      </div>
      <span class="tag ${tag === "Hot" ? "hot" : ""}">${tag}</span>
    </article>
  `).join("");
}

function renderCatalog() {
  catalogList.innerHTML = catalog.map((item) => `
    <article class="catalog-card">
      <img class="catalog-thumb" src="${item.image || "assets/IMG_6475.png"}" alt="${item.name}">
      <div class="catalog-info">
        <h3>${item.name}</h3>
        <p>$${item.price.toFixed(2)} - ${item.category}</p>
        <p>${item.description || "No description yet."}</p>
      </div>
      <div class="catalog-actions">
        <span class="tag ${item.active ? "" : "hot"}">${item.active ? "Live" : "Paused"}</span>
        <button class="ghost-button" type="button" data-edit-item="${item.id}">Edit</button>
        <button class="ghost-button" type="button" data-toggle-item="${item.id}">
          ${item.active ? "Pause" : "Live"}
        </button>
        <button class="danger-button" type="button" data-delete-item="${item.id}">Remove</button>
      </div>
    </article>
  `).join("");

  catalogList.querySelectorAll("[data-toggle-item]").forEach((button) => {
    button.addEventListener("click", () => {
      catalog = catalog.map((item) => {
        if (item.id !== button.dataset.toggleItem) return item;
        return { ...item, active: !item.active };
      });
      saveCatalog();
      renderCatalog();
    });
  });

  catalogList.querySelectorAll("[data-edit-item]").forEach((button) => {
    button.addEventListener("click", () => {
      const item = catalog.find((catalogItem) => catalogItem.id === button.dataset.editItem);
      if (!item) return;

      editingItemId = item.id;
      pendingImageData = "";
      itemNameInput.value = item.name;
      itemPriceInput.value = item.price;
      itemDescriptionInput.value = item.description || "";
      itemCategoryInput.value = item.category;
      itemImageUrlInput.value = item.image || "";
      itemImageFileInput.value = "";
      catalogSubmitButton.textContent = "Save item";
      cancelEditButton.hidden = false;
      catalogForm.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });

  catalogList.querySelectorAll("[data-delete-item]").forEach((button) => {
    button.addEventListener("click", () => {
      catalog = catalog.filter((item) => item.id !== button.dataset.deleteItem);
      saveCatalog();
      renderCatalog();
    });
  });
}

modeButtons.forEach((button) => {
  button.addEventListener("click", () => setMode(button.dataset.mode));
});

document.querySelectorAll(".category").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".category").forEach((category) => category.classList.remove("active"));
    button.classList.add("active");
    activeFilter = button.dataset.filter;
    renderMerchants();
  });
});

searchInput.addEventListener("input", renderMerchants);

document.getElementById("quickAddButton").addEventListener("click", () => addToBasket(4));

document.getElementById("checkoutButton").addEventListener("click", () => {
  if (basketCount === 0) {
    basketSummary.textContent = "Add items first";
    return;
  }

  basketSummary.textContent = "Checkout ready";
});

document.getElementById("locationButton").addEventListener("click", () => {
  const locationText = document.getElementById("locationText");
  locationText.textContent = locationText.textContent === "Mission District" ? "SoMa" : "Mission District";
});

accessForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const submittedCode = accessCodeInput.value.trim().toUpperCase();

  if (submittedCode === accessCode) {
    unlockApp();
    return;
  }

  accessError.textContent = "Access code not recognized.";
});

document.getElementById("lockAppButton").addEventListener("click", lockApp);

itemImageFileInput.addEventListener("change", async () => {
  const file = itemImageFileInput.files[0];
  pendingImageData = file ? await readUploadedImage(file) : "";
  if (pendingImageData) itemImageUrlInput.value = "";
});

promoInputs.logoFile.addEventListener("change", async () => {
  const file = promoInputs.logoFile.files[0];
  pendingLogoData = file ? await readUploadedImage(file) : "";
  if (pendingLogoData) promoInputs.logoImage.value = "";
});

promoInputs.heroFile.addEventListener("change", async () => {
  const file = promoInputs.heroFile.files[0];
  pendingHeroData = file ? await readUploadedImage(file) : "";
  if (pendingHeroData) promoInputs.heroImage.value = "";
});

cancelEditButton.addEventListener("click", resetCatalogForm);

catalogForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const name = itemNameInput.value.trim();
  const price = Number(itemPriceInput.value);
  const category = itemCategoryInput.value;
  const description = itemDescriptionInput.value.trim();

  if (!name || Number.isNaN(price)) return;

  const currentItem = catalog.find((item) => item.id === editingItemId);
  const image = pendingImageData || itemImageUrlInput.value.trim() || currentItem?.image || "assets/IMG_6475.png";
  const itemData = { name, price, category, description, image };

  if (editingItemId) {
    catalog = catalog.map((item) => item.id === editingItemId ? { ...item, ...itemData } : item);
  } else {
    catalog = [
      { id: `item-${Date.now()}`, ...itemData, active: true },
      ...catalog
    ];
  }

  saveCatalog();
  renderCatalog();
  resetCatalogForm();
});

document.getElementById("resetCatalogButton").addEventListener("click", () => {
  catalog = [...defaultCatalog];
  saveCatalog();
  renderCatalog();
  resetCatalogForm();
});

designForm.addEventListener("submit", (event) => {
  event.preventDefault();
  design = {
    name: brandNameInput.value.trim() || defaultDesign.name,
    color: brandColorInput.value || defaultDesign.color,
    preset: stylePresetInput.value || defaultDesign.preset
  };
  saveDesign();
  applyDesign();
});

document.getElementById("resetDesignButton").addEventListener("click", () => {
  design = { ...defaultDesign };
  saveDesign();
  applyDesign();
});

frontPageForm.addEventListener("submit", (event) => {
  event.preventDefault();
  frontPage = {
    ...frontPage,
    heroEyebrow: frontPageInputs.heroEyebrow.value.trim() || defaultFrontPage.heroEyebrow,
    heroTitle: frontPageInputs.heroTitle.value.trim() || defaultFrontPage.heroTitle,
    heroDescription: frontPageInputs.heroDescription.value.trim() || defaultFrontPage.heroDescription,
    brandEyebrow: frontPageInputs.brandEyebrow.value.trim() || defaultFrontPage.brandEyebrow,
    brandHeadline: frontPageInputs.brandHeadline.value.trim() || defaultFrontPage.brandHeadline,
    brandDescription: frontPageInputs.brandDescription.value.trim() || defaultFrontPage.brandDescription,
    featuredDrop: frontPageInputs.featuredDrop.value.trim() || defaultFrontPage.featuredDrop,
    featuredDescription: frontPageInputs.featuredDescription.value.trim() || defaultFrontPage.featuredDescription,
    flowerNote: frontPageInputs.flowerNote.value.trim() || defaultFrontPage.flowerNote,
    syrupNote: frontPageInputs.syrupNote.value.trim() || defaultFrontPage.syrupNote,
    apparelNote: frontPageInputs.apparelNote.value.trim() || defaultFrontPage.apparelNote
  };
  saveFrontPage();
  applyFrontPage();
});

document.getElementById("resetFrontPageButton").addEventListener("click", () => {
  frontPage = { ...defaultFrontPage };
  saveFrontPage();
  applyFrontPage();
});

promoForm.addEventListener("submit", (event) => {
  event.preventDefault();
  promo = {
    visible: promoInputs.visible.checked,
    eyebrow: promoInputs.eyebrow.value.trim() || defaultPromo.eyebrow,
    headline: promoInputs.headline.value.trim() || defaultPromo.headline,
    description: promoInputs.description.value.trim() || defaultPromo.description,
    button: promoInputs.button.value.trim() || defaultPromo.button,
    logoImage: pendingLogoData || promoInputs.logoImage.value.trim() || promo.logoImage,
    heroImage: pendingHeroData || promoInputs.heroImage.value.trim() || promo.heroImage
  };
  pendingLogoData = "";
  pendingHeroData = "";
  promoInputs.logoFile.value = "";
  promoInputs.heroFile.value = "";
  savePromo();
  applyPromo();
});

document.getElementById("resetPromoButton").addEventListener("click", () => {
  promo = { ...defaultPromo };
  pendingLogoData = "";
  pendingHeroData = "";
  promoInputs.logoFile.value = "";
  promoInputs.heroFile.value = "";
  savePromo();
  applyPromo();
});

initializeAccessGate();
applyDesign();
applyFrontPage();
applyPromo();
renderMerchants();
renderCards("merchantOrders", merchantOrders, "order-card");
renderCatalog();

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}
